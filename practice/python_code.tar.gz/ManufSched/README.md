# ManufSched

*ManufSched* stands for Manufacturing Scheduling. This projects aims to create a complete software package which demonstartes a scheduling engine working in conjunction with an ERP(Enterprise Resourse Planning) and MES(Manufacturing Execution System) to optimize the flow of jobs on the shop floor in real time. This project has just began.


This project at the current stage aims to do the following:

1. Collect various scheduling algorithms and write them in python.
2. ...
3. ...


If you wish to contribute or join us in any way email me at [sanap.tejas@gmail.com](mailto:sanap.tejas@gmail.com) or join the [gitter channel](https://gitter.im/manufsched).
