## Things to do.

1. Enable [InputPTMatrix.py](https://github.com/sanaptejas/ManufSched/blob/master/InputPTMatrix.py) to take input sequence.
2. Enable [Heurestics_Palmer.py](https://github.com/sanaptejas/ManufSched/blob/master/Heurestics_Palmer.py) to take weights of each machine as input.
3. Add more heurestic algorithms such as CDS and NEH.
4. Modify [JohnsonsThreeMachineFunction.py](https://github.com/sanaptejas/ManufSched/blob/master/JohnsonsThreeMachineFunction.py) to support input functions from [InputPTMatrix.py](https://github.com/sanaptejas/ManufSched/blob/master/InputPTMatrix.py) and makespan calculations from [MeasureMakespanFunction.py](https://github.com/sanaptejas/ManufSched/blob/master/MeasureMakespanFunction.py).
5. ...
