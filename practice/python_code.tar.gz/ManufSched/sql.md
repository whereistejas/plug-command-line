1. `PGHOST` and `PGPORT` have to be set.
